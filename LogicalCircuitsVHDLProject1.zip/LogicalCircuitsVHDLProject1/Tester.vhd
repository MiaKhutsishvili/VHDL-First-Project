--------------------------------------------------------------------------------
-- Company: 
-- Engineer:
--
-- Create Date:   20:37:42 05/16/2025
-- Design Name:   
-- Module Name:   /home/ise/LogicalCircuitsVHDLProject1/Tester.vhd
-- Project Name:  LogicalCircuitsVHDLProject1
-- Target Device:  
-- Tool versions:  
-- Description:   
-- 
-- VHDL Test Bench Created by ISE for module: TopModule
-- 
-- Dependencies:
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
-- Notes: 
-- This testbench has been automatically generated using types std_logic and
-- std_logic_vector for the ports of the unit under test.  Xilinx recommends
-- that these types always be used for the top-level I/O of a design in order
-- to guarantee that the testbench will bind correctly to the post-implementation 
-- simulation model.
--------------------------------------------------------------------------------
LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
 
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--USE ieee.numeric_std.ALL;
 
ENTITY Tester IS
END Tester;
 
ARCHITECTURE behavior OF Tester IS 
 
    -- Component Declaration for the Unit Under Test (UUT)
 
    COMPONENT TopModule
    PORT(
         DataInE : IN  std_logic_vector(7 downto 0);
         OddMode : IN  std_logic;
         Error : IN  std_logic_vector(12 downto 0);
         Output : OUT  std_logic_vector(7 downto 0);
         Valid : OUT  std_logic
        );
    END COMPONENT;
    

   --Inputs
   signal DataInE : std_logic_vector(7 downto 0) := "01101011";
   signal OddMode : std_logic := '1';
   signal Error : std_logic_vector(12 downto 0) := "1001000000000";

 	--Outputs
   signal Output : std_logic_vector(7 downto 0);
   signal Valid : std_logic;
   -- No clocks detected in port list. Replace <clock> below with 
   -- appropriate port name 
 
BEGIN
 
	-- Instantiate the Unit Under Test (UUT)
uut: TopModule PORT MAP (
          DataInE => DataInE,
          OddMode => OddMode,
          Error => Error,
          Output => Output,
          Valid => Valid
        );

--process
--begin
--	report "Out: " & std_logic'image(OddMode);
--	report "OddMode: " & std_logic'image(OddMode);
--	wait;
--end process;

END;
