--------------------------------------------------------------------------------
-- Company: 
-- Engineer:
--
-- Create Date:   21:06:58 05/16/2025
-- Design Name:   
-- Module Name:   /home/ise/LogicalCircuitsVHDLProject1/EncoderTester.vhd
-- Project Name:  LogicalCircuitsVHDLProject1
-- Target Device:  
-- Tool versions:  
-- Description:   
-- 
-- VHDL Test Bench Created by ISE for module: TheEncoder
-- 
-- Dependencies:
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
-- Notes: 
-- This testbench has been automatically generated using types std_logic and
-- std_logic_vector for the ports of the unit under test.  Xilinx recommends
-- that these types always be used for the top-level I/O of a design in order
-- to guarantee that the testbench will bind correctly to the post-implementation 
-- simulation model.
--------------------------------------------------------------------------------
LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
 
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--USE ieee.numeric_std.ALL;
 
ENTITY EncoderTester IS
END EncoderTester;
 
ARCHITECTURE behavior OF EncoderTester IS 
 
    -- Component Declaration for the Unit Under Test (UUT)
 
    COMPONENT TheEncoder
    PORT(
         DataInE : IN  std_logic_vector(7 downto 0);
         OddMode : IN  std_logic;
         DataOutE : OUT  std_logic_vector(12 downto 0)
        );
    END COMPONENT;
    

   --Inputs
   signal DataInE : std_logic_vector(7 downto 0) := (others => '0');
   signal OddMode : std_logic := '0';

 	--Outputs
   signal DataOutE : std_logic_vector(12 downto 0);
   -- No clocks detected in port list. Replace <clock> below with 
   -- appropriate port name 
 
   constant <clock>_period : time := 10 ns;
 
BEGIN
 
	-- Instantiate the Unit Under Test (UUT)
   uut: TheEncoder PORT MAP (
          DataInE => DataInE,
          OddMode => OddMode,
          DataOutE => DataOutE
        );

   -- Clock process definitions
   <clock>_process :process
   begin
		<clock> <= '0';
		wait for <clock>_period/2;
		<clock> <= '1';
		wait for <clock>_period/2;
   end process;
 

   -- Stimulus process
   stim_proc: process
   begin		
      -- hold reset state for 100 ns.
      wait for 100 ns;	

      wait for <clock>_period*10;

      -- insert stimulus here 

      wait;
   end process;

END;
