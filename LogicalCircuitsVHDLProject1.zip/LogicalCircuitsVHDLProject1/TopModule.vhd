library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TopModule is
    Port ( DataInE : in  STD_LOGIC_VECTOR (7 downto 0);
           OddMode : in  STD_LOGIC;
           Error : in  STD_LOGIC_VECTOR (12 downto 0);
           Output : out  STD_LOGIC_VECTOR (7 downto 0);
           Valid : out  STD_LOGIC);
end TopModule;

architecture Behavioral of TopModule is

signal DataOutE : STD_LOGIC_VECTOR (12 downto 0);
signal DataIn : STD_LOGIC_VECTOR (12 downto 0);
signal DataOut : STD_LOGIC_VECTOR (7 downto 0);

component TheEncoder
    Port ( DataInE : in  STD_LOGIC_VECTOR (7 downto 0);
           OddMode : in  STD_LOGIC;
           DataOutE : out  STD_LOGIC_VECTOR (12 downto 0));
end component;

component TheDecoder 
    Port ( DataIn : in  STD_LOGIC_VECTOR (12 downto 0);
           OddMode : in  STD_LOGIC;
           DataOut : out  STD_LOGIC_VECTOR (7 downto 0);
           Valid : out  STD_LOGIC);
end component;

begin

U1: TheEncoder 
	port map (
		DataInE => DataInE,
		OddMode => OddMode,
		DataOutE => DataOutE
		);

DataIn(0) <= DataOutE(0) xor Error(0);
DataIn(1) <= DataOutE(1) xor Error(1);
DataIn(2) <= DataOutE(2) xor Error(2);
DataIn(3) <= DataOutE(3) xor Error(3);
DataIn(4) <= DataOutE(4) xor Error(4);
DataIn(5) <= DataOutE(5) xor Error(5);
DataIn(6) <= DataOutE(6) xor Error(6);
DataIn(7) <= DataOutE(7) xor Error(7);
DataIn(8) <= DataOutE(8) xor Error(8);
DataIn(9) <= DataOutE(9) xor Error(9);
DataIn(10) <= DataOutE(10) xor Error(10);
DataIn(11) <= DataOutE(11) xor Error(11);
DataIn(12) <= DataOutE(12) xor Error(12);

U2: TheDecoder 
	port map (
		DataIn => DataIn,
		OddMode => OddMode,
		DataOut => DataOut,
		Valid => Valid
		);

Output(0) <= DataOut(0);
Output(1) <= DataOut(1);
Output(2) <= DataOut(2);
Output(3) <= DataOut(3);
Output(4) <= DataOut(4);
Output(5) <= DataOut(5);
Output(6) <= DataOut(6);
Output(7) <= DataOut(7);

end Behavioral;

