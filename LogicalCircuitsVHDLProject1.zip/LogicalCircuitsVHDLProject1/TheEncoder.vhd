library IEEE;
library work;

use IEEE.STD_LOGIC_1164.ALL;

entity TheEncoder is
    Port ( DataInE : in  STD_LOGIC_VECTOR (7 downto 0);
           OddMode : in  STD_LOGIC;
           DataOutE : out  STD_LOGIC_VECTOR (12 downto 0));
end TheEncoder;

architecture Behavioral of TheEncoder is

signal parity : STD_LOGIC_VECTOR (4 downto 0);

begin

parity(0) <= ((((DataInE(0) xor DataInE(1)) xor DataInE(3)) xor DataInE(4)) xor DataInE(6)) xor (not OddMode); 
parity(1) <= ((((DataInE(0) xor DataInE(2)) xor DataInE(3)) xor DataInE(5)) xor DataInE(6)) xor (not OddMode); 
parity(2) <= (((DataInE(1) xor DataInE(2)) xor DataInE(3)) xor DataInE(7)) xor (not OddMode); 
parity(3) <= (((DataInE(4) xor DataInE(5)) xor DataInE(6)) xor DataInE(7)) xor (not OddMode); 

-- Main Data
DataOutE(0) <= parity(0);
DataOutE(1) <= parity(1);
DataOutE(2) <= DataInE(0);
DataOutE(3) <= parity(2);
DataOutE(4) <= DataInE(1);
DataOutE(5) <= DataInE(2);
DataOutE(6) <= DataInE(3);
DataOutE(7) <= parity(3);
DataOutE(8) <= DataInE(4);
DataOutE(9) <= DataInE(5);
DataOutE(10) <= DataInE(6);
DataOutE(11) <= DataInE(7);

-- Bit 13 Parity
parity(4) <= (((((((((((DataInE(0) xor DataInE(1)) xor DataInE(2)) xor DataInE(3)) xor DataInE(4)) xor DataInE(5)) 
				       xor DataInE(6)) xor DataInE(7)) xor parity(0)) xor parity(1)) xor parity(2)) xor parity(3)) 
						 xor (not OddMode);
DataOutE(12) <= parity(4);

end Behavioral;

