library IEEE;
library work;

use IEEE.STD_LOGIC_1164.ALL;

entity TheDecoder is
    Port ( DataIn : in  STD_LOGIC_VECTOR (12 downto 0);
           OddMode : in  STD_LOGIC;
           DataOut : out  STD_LOGIC_VECTOR (7 downto 0);
           Valid : out  STD_LOGIC);
end TheDecoder;

architecture Behavioral of TheDecoder is

signal Q : STD_LOGIC_VECTOR (4 downto 0);
signal Checker : STD_LOGIC_VECTOR (3 downto 0);
signal Corrected : STD_LOGIC_VECTOR (12 downto 0);

begin

Q(0) <= ((((DataIn(2) xor DataIn(4)) xor DataIn(6)) xor DataIn(8)) xor DataIn(10)) xor (not OddMode); -- New Parity 1
Q(1) <= ((((DataIn(2) xor DataIn(5)) xor DataIn(6)) xor DataIn(9)) xor DataIn(10)) xor (not OddMode); -- New Parity 2
Q(2) <= (((DataIn(4) xor DataIn(5)) xor DataIn(6)) xor DataIn(11)) xor (not OddMode); -- New Parity 3
Q(3) <= (((DataIn(8) xor DataIn(9)) xor DataIn(10)) xor DataIn(11)) xor (not OddMode); -- New Parity 4

Checker(0) <= Q(0) xor DataIn(0);
Checker(1) <= Q(1) xor DataIn(1);
Checker(2) <= Q(2) xor DataIn(3);
Checker(3) <= Q(3) xor DataIn(7);

Corrected(0) <= DataIn(0) xor ((((Checker(0)) and (not Checker(1))) and (not Checker(2))) and (not Checker(3)));
Corrected(1) <= DataIn(1) xor ((((not Checker(0)) and (Checker(1))) and (not Checker(2))) and (not Checker(3)));
Corrected(2) <= DataIn(2) xor ((((Checker(0)) and (Checker(1))) and (Checker(2))) and (not Checker(3)));
Corrected(3) <= DataIn(3) xor ((((not Checker(0)) and (not Checker(1))) and (not Checker(2))) and (not Checker(3)));
Corrected(4) <= DataIn(4) xor ((((Checker(0)) and (not Checker(1))) and (Checker(2))) and (not Checker(3)));
Corrected(5) <= DataIn(5) xor ((((not Checker(0)) and (Checker(1))) and (Checker(2))) and (not Checker(3)));
Corrected(6) <= DataIn(6) xor ((((Checker(0)) and (Checker(1))) and (Checker(2))) and (not Checker(3)));
Corrected(7) <= DataIn(7) xor ((((not Checker(0)) and (not Checker(1))) and (not Checker(2))) and (Checker(3)));
Corrected(8) <= DataIn(8) xor ((((Checker(0)) and (not Checker(1))) and (not Checker(2))) and (Checker(3)));
Corrected(9) <= DataIn(9) xor ((((not Checker(0)) and (Checker(1))) and (not Checker(2))) and (Checker(3)));
Corrected(10) <= DataIn(10) xor ((((Checker(0)) and (Checker(1))) and (not Checker(2))) and (Checker(3)));
Corrected(11) <= DataIn(11) xor ((((not Checker(0)) and (not Checker(1))) and (Checker(2))) and (Checker(3)));
Corrected(12) <= DataIn(12);

Q(4) <= (((((((((((Corrected(0) xor Corrected(1)) xor Corrected(2)) xor Corrected(3)) xor Corrected(4)) xor Corrected(5)) 
				       xor Corrected(6)) xor Corrected(7)) xor Corrected(8)) xor Corrected(9)) xor Corrected(10)) xor Corrected(11)) 
						 xor (not OddMode);

Valid <= ((Q(4) xor Corrected(12)) and ((not Checker(0)) and (not Checker(1)) and (not Checker(2)) and (not Checker(3)))) or 
			(not (Q(4) xor Corrected(12)));
			
DataOut(0) <= Corrected(2);
DataOut(1) <= Corrected(4);
DataOut(2) <= Corrected(5);
DataOut(3) <= Corrected(6);
DataOut(4) <= Corrected(8);
DataOut(5) <= Corrected(9);
DataOut(6) <= Corrected(10);
DataOut(7) <= Corrected(11);

end Behavioral;

